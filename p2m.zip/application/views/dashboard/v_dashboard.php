
        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles 
         <div class="row top_tiles">
              <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i class="fa fa-caret-square-o-right"></i></div>
                  <div class="count">179</div>
                  <h3>New Sign ups</h3>
                  <p>Lorem ipsum psdea itgum rixt.</p>
                </div>
              </div>
              <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i class="fa fa-comments-o"></i></div>
                  <div class="count">179</div>
                  <h3>New Sign ups</h3>
                  <p>Lorem ipsum psdea itgum rixt.</p>
                </div>
              </div>
              <div class=" col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i class="fa fa-sort-amount-desc"></i></div>
                  <div class="count">179</div>
                  <h3>New Sign ups</h3>
                  <p>Lorem ipsum psdea itgum rixt.</p>
                </div>
              </div>
              <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i class="fa fa-check-square-o"></i></div>
                  <div class="count">179</div>
                  <h3>New Sign ups</h3>
                  <p>Lorem ipsum psdea itgum rixt.</p>
                </div>
              </div>
            </div>-->

            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Dokumen dan Data yang diperlukan </h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                      <h6>jjjjjjjjjjjjjjjjjjjj</h6>
                      <h6>jjjjjjjjjjjjjjjjjjjj</h6>
                      <h6>jjjjjjjjjjjjjjjjjjjj</h6>
                      <h6>jjjjjjjjjjjjjjjjjjjj</h6>
                      <h6>jjjjjjjjjjjjjjjjjjjj</h6>
                      <h6>jjjjjjjjjjjjjjjjjjjj</h6>
                      <h6>jjjjjjjjjjjjjjjjjjjj</h6>
                   
                    </div>

                  
                  </div>
                </div>
              </div>
            </div>
        </div>

