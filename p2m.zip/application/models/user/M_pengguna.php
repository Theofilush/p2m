<?php 
defined('BASEPATH') OR exit('Anda tidak boleh mengakses file ini secara langsung'); 
class M_pengguna extends CI_Model{



}
?>
